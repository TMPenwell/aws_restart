print("Count to 10!")

for x in range (5, 20):
    print(x)